Programming project of 

Lara KOEHLER

Gr�goire ROUSSEL



INSTALLATION : 
please copy data files (*.in) in data/

RUN

the main function is located in Networks/Nerworks.java.

Differents actions are proposed, please uncomment the desired section


GRAPHS
normal plots can be seen with Vis2.html
isochrones are to be opened with VisIsochrone.html

